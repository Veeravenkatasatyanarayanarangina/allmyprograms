package com.motivity.hospital.exception;

public class NoIdPresentsException extends RuntimeException{

	public NoIdPresentsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
