package com.motivity.hospital.exception;

public class PasswordMisMatchException extends RuntimeException{

	public PasswordMisMatchException(String message) {
		super(message);
		
	}
}
