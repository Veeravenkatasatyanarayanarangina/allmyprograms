package com.motivity.factorypattern;

public class FirstClass extends TrainTicketsPrice
{
    @Override
    void getPrice() {
        price =1500.00;
    }
}
