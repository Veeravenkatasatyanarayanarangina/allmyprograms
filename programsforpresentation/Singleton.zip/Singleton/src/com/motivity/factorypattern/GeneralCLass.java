package com.motivity.factorypattern;

public class GeneralCLass extends TrainTicketsPrice
{
    @Override
    void getPrice() {
        super.price = 450.00;
    }
}
