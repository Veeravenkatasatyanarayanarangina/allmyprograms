package com.motivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwttokenpractice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
