package com.motivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jwttokenpractice1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jwttokenpractice1Application.class, args);
	}

}
