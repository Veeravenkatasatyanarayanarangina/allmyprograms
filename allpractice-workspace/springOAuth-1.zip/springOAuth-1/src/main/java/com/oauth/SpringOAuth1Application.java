package com.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOAuth1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringOAuth1Application.class, args);
	}

}
