

//local api
 //export const baseURL ='http://localhost:8080/'
// Server Api
// export const baseURL ='https://ml-hospital-mngmt.azurewebsites.net/'
//vm Api
//export const baseURL ='http://172.174.209.218:8080/'
export const baseURL ='https://1129-182-76-136-42.in.ngrok.io/'