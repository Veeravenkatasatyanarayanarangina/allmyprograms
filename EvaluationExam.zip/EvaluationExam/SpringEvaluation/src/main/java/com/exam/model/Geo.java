package com.exam.model;

public class Geo {

	 public String lat;
	    public String lng;
}
